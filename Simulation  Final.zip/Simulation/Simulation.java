//Predator Prey Simulation
//Doodlebugs and ants move around
//a grid. if a doodlebug lands on an ant
//the ant is eaten by the doodlebug.
//If an ant lives for 3 turns it breeds.
//If a doodlebug lives for 8 turns it breeds
//If a doodlebug doesnt eat for 3 turns it starves


import java.util.*;
import java.awt.*;
import java.io.*;
import java.lang.*;
import javax.swing.*;
import javax.swing.JFrame;
/*
//Simulation class

*/
public class Simulation extends JFrame{
    public static Scanner s = new Scanner(System.in);
    public JPanel grid;
    public int rows;
    public int cols;
    public JLabel[][] panelgrids;
    public ImageIcon antsIcon = loadImage("images/ant_icon.png", 20, 20);
    public ImageIcon bugsIcon = loadImage("images/bug_icon.png", 20, 20);

    //Main function for ants and bugs simulation
    public static void main(String[] args){
        World world = new World(100,5);//////////ants/bugs
        Simulation sim = new Simulation("Pred/Prey", 20, 20 );
        sim.setGrid( world.getCGrid() );
        String input = "1";
        int timesteps = 1;
        boolean playing = true;
        while(playing){
            System.out.println("[ENTER] Next timestep.");
            
            input = s.nextLine();
            if(input.equals("Q")||input.equals("q")){
                playing = false;

                continue;
            }
            else if(input.equals("")){
                timestep(timesteps,world);
            }
            else if(isNum(input)){
                timesteps = Integer.parseInt(input);
                timestep(timesteps,world);
            }
            else{
                System.out.println("Try again!");
                continue;
            }
            sim.setGrid( world.getCGrid() );
        }

    }
    //Simulation constructor
    public Simulation(String title, int x, int y) {
        setTitle( title );
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE );

        gridpanel(x, y);
        
        pack();
        setVisible( true );
    }

    // Sets grid cells to values in array, data
    public void setGrid( char [][] data ) {
        for (int i = 0; i < data.length; i++ ) {
            for (int j = 0; j < data[i].length; j++ ) {
                makeGrid( i, j, data[i][j] );
            }
        }
    }
    public static void timestep(int timesteps, World w){
        for(int i = timesteps; i > 0; i--){
            w.starveAll();
            w.moveAll();
            w.breedAll();
        }
    }
    public static boolean isNum(String s){
        try{
            Integer.parseInt(s);
        } catch(NumberFormatException nfe) {
            return false;
        }
        return true;
    }
    
    private ImageIcon loadImage(String path, int w, int h){
        Image image = new ImageIcon(this.getClass().getResource(path)).getImage();
        Image scaledImage = image.getScaledInstance(w, h,  java.awt.Image.SCALE_SMOOTH);
        return new ImageIcon(scaledImage);
    }

    
    //To create grid panel
    public void gridpanel(int r, int c) {
        rows = r;
        cols = c;
        panelgrids = new JLabel[rows][cols];

        setLayout (new GridLayout(rows, cols, 0, 0));
        setBackground( new Color( 200,200,200 ) );

        for (int i = 0; i < rows; i++ ) {
            for (int j = 0; j < cols; j++ ) {
                panelgrids[i][j] = new JLabel();
                panelgrids[i][j].setBorder( BorderFactory.createLineBorder(Color.BLACK,1) );
                panelgrids[i][j].setFont( new Font("Courier", Font.BOLD, 12));
                panelgrids[i][j].setForeground(Color.WHITE);
                panelgrids[i][j].setHorizontalAlignment(SwingConstants.CENTER);
                add( panelgrids[i][j] );
            }
        }
        setPreferredSize( new Dimension(500,500) );
    }
    
    //To generate ants and bugs into the simulation
    public void makeGrid(int i, int j, char value) {
        if (value == '.')
            value = ' '; // change dot to space

        panelgrids[i][j].setText( "" + value );
        switch (value) {
            case 'A': // ant
                //panelgrids[i][j].setBackground( Color.MAGENTA );
                panelgrids[i][j].setIcon(antsIcon);
                panelgrids[i][j].setOpaque(true);
                break;
            case 'B': // doodlebug
                //panelgrids[i][j].setBackground( Color.BLUE );
                panelgrids[i][j].setIcon(bugsIcon);
                panelgrids[i][j].setOpaque(true);
                break;
            default:
                panelgrids[i][j].setOpaque(false);
                break;
        }
        
        if(value == 'A')
        {
            panelgrids[i][j].setIcon(antsIcon);
        }
        else if(value == 'B')
        {
            panelgrids[i][j].setIcon(bugsIcon);
        }
    }

    
}

