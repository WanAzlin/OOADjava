import java.awt.*;
import java.io.*;
import java.util.*;
/*
//Bug class
*/
public class Bug extends Organism {
    private static Random r = new Random();
    private int untilBreed;
    private int untilStarve;
    
    //Bug constructor
    public Bug( World world,int _x, int _y){
        super(world, _x, _y );
        untilBreed = 8;
        untilStarve = 3;
        moved = false;
    }
    @Override
    //To initialize bugs movement
    public void move() {
        if(!moved) {
            //potential directions in order
            int[] potMoves = new int[4];
            int i = 1;
            potMoves[0] = r.nextInt(4);
            do{
                do{
                    potMoves[i] = r.nextInt(4);
                }
                while(potMoves[i]!=potMoves[i-1]);
                i++;
            }
            while(i<4);
            i = 0;
            boolean empty = false;
            int oldx = x;
            int oldy = y;

            /*while(i<4 && !empty){
                switch(potMoves[i]){
                    case 0:
                        if(x > 0){
                            if(world.isAnt(x-1,y)){
                                empty = true;

                                world.setCell(x-1,y,this);
                                world.setCell(oldx,y,null);
                                moved = true;
                                untilBreed--;
                                untilStarve=3;
                                x=x-1;
                                System.out.println("ate ant: x: " + x + ", y: " + y);
                            }
                        }
                        break;
                    case 1:
                        if(x < 19){
                            if(world.isAnt(x+1,y)){
                                empty = true;
                                
                                world.setCell(x+1,y,this);
                                world.setCell(oldx,y,null);
                                moved = true;
                                untilBreed--;
                                untilStarve=3;
                                x=x+1;
                                System.out.println("ate ant: x: " + x + ", y: " + y);
                            }
                        }
                        break;
                    case 2:
                        if(y > 0){
                            if(world.isAnt(x,y-1)){

                                world.setCell(x,y-1,this);
                                world.setCell(x,oldy,null);
                                moved = true;
                                empty = true;
                                y=y-1;
                                untilBreed--;
                                untilStarve=3;
                                System.out.println("ate ant: x: " + x + ", y: " + y);
                            }
                        }
                        break;
                    case 3:
                        if(y < 19){
                            if(world.isAnt(x,y+1)){
                                world.setCell(x,y+1,this);
                                world.setCell(x,oldy,null);
                                moved = true;
                                empty = true;
                                y=y+1;
                                untilBreed--;
                                untilStarve=3;
                                System.out.println("ate ant: x: " + x + ", y: " + y);
                            }
                        }
                        break;
                }
                i++;
            }*/
            
           
            if(world.inBoundaries(x+1, y) && world.isAnt(x+1,y)){
                empty = true;

                world.setCell(x+1,y,this);
                world.setCell(oldx,y,null);
                moved = true;
                untilBreed--;
                untilStarve=3;
                x=x+1;
            }
            else if(world.inBoundaries(x-1, y) && world.isAnt(x-1,y)){
                empty = true;

                world.setCell(x-1,y,this);
                world.setCell(oldx,y,null);
                moved = true;
                untilBreed--;
                untilStarve=3;
                x=x-1;
            }
            else if(world.inBoundaries(x, y+1) && world.isAnt(x,y+1)){
                empty = true;

                world.setCell(x,y+1,this);
                world.setCell(x,oldy,null);
                moved = true;
                untilBreed--;
                untilStarve=3;
                y=y+1;
            }
            else if(world.inBoundaries(x, y-1) && world.isAnt(x,y-1)){
                empty = true;

                world.setCell(x,y-1,this);
                world.setCell(x,oldy,null);
                moved = true;
                untilBreed--;
                untilStarve=3;
                y=y-1;
            }
                        
            
            i= 0;
            while(i<4 && !empty){
                switch(potMoves[i]){
                    case 0:
                        if(x > 0){
                            if(world.isEmpty(x-1,y)){
                                empty = true;

                                world.setCell(x-1,y,this);
                                world.setCell(oldx,y,null);
                                moved = true;
                                untilBreed--;
                                untilStarve--;
                                x=x-1;
                            }
                        }
                        break;
                    case 1:
                        if(x < 19){
                            if(world.isEmpty(x+1,y)){
                                untilBreed--;
                                untilStarve--;
                                world.setCell(x+1,y,this);
                                world.setCell(oldx,y,null);
                                moved = true;
                                empty = true;
                                x=x+1;
                            }
                        }
                        break;
                    case 2:
                        if(y > 0){
                            if(world.isEmpty(x,y-1)){

                                world.setCell(x,y-1,this);
                                world.setCell(x,oldy,null);
                                moved = true;
                                empty = true;
                                y=y-1;
                                untilBreed--;
                                untilStarve--;
                            }
                        }
                        break;
                    case 3:
                        if(y < 19){
                            if(world.isEmpty(x,y+1)){
                                world.setCell(x,y+1,this);
                                world.setCell(x,oldy,null);
                                moved = true;
                                empty = true;
                                y=y+1;
                                untilBreed--;
                                untilStarve--;
                            }
                        }
                        break;
                }
                i++;
            }
            
            if(!empty){
                untilBreed = 8;
                untilStarve--;
            }
            
        }


    }
    //To initialize bugs breeding
    public void breed(){
        
        if(untilBreed <= 0){
            //potential directions in order
            int[] potMoves = new int[4];
            int i = 1;
            potMoves[0] = r.nextInt(4);
            do{
                do{
                    potMoves[i] = r.nextInt(4);
                }
                while(potMoves[i]!=potMoves[i-1]);
                i++;
            }
            while(i<4);
            i = 0;
            boolean empty = false;
            int oldx = x;
            int oldy = y;
            while(i<4 && !empty){
                switch(potMoves[i]){
                    case 0:
                        if(x > 0){
                            if(world.isEmpty(x-1,y)){
                                world.setCell(x-1,y,new Bug(world, x-1,y));
                                untilBreed = 8;
                                empty = true;
                            }
                        }
                        break;
                    case 1:
                        if(x < 19){
                            if(world.isEmpty(x+1,y)){
                                world.setCell(x+1,y,new Bug(world, x+1,y));
                                untilBreed=8;
                                empty = true;
                            }
                        }
                        break;
                    case 2:
                        if(y > 0){
                            if(world.isEmpty(x,y-1)){
                                world.setCell(x,y-1,new Bug(world, x,y-1));
                                untilBreed=8;
                                empty = true;

                            }
                        }
                        break;
                    case 3:
                        if(y < 19){
                            if(world.isEmpty(x,y+1)){
                                world.setCell(x,y+1,new Bug(world, x,y+1));
                                untilBreed=8;
                                empty = true;
                            }
                        }
                        break;
                }
                i++;
            }
        }

    }
    //To check if the bugs has not eat any ants for the next three(3) timestep the bugs will die
    public void starve() {
        if(untilStarve <= 0)
            world.setCell(x,y,null);
    }
}


