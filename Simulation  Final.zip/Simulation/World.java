import java.util.*;
import java.awt.*;
import javax.swing.*;
/*
//World class
*/
public class World{

    private static Random r= new Random();
    private int bugs;
    private int ants;
    private static final int SIZE = 20;
    private Organism[][] oGrid;
    private ImageIcon antsIcon = new ImageIcon("ants_icon.png");
    private ImageIcon bugsIcon = new ImageIcon("bugs_icon.png");

    //constructor\\
    World(int a,int b){
        oGrid = new Organism[SIZE][SIZE];
        bugs = b;
        ants = a;
        for(int i = 0; i < b; i++){
            boolean isOccupied = true;
            //potential x & y
            while(isOccupied){
                int potX = r.nextInt(SIZE);
                int potY = r.nextInt(SIZE);
                if(oGrid[potX][potY] == null)
                {
                    isOccupied = false;
                    oGrid[potX][potY] = new Bug(this,potX,potY);
                }
            }
        }
        for(int i = 0; i < a; i++){
            boolean isOccupied = true;
            //potential x & y
            while(isOccupied){
                int potX = r.nextInt(SIZE);
                int potY = r.nextInt(SIZE);
                if(oGrid[potX][potY] == null)
                {
                    isOccupied = false;
                    oGrid[potX][potY] = new Ant(this,potX,potY);
                }
            }
        }
        
    }
    //accessors\\
    public int getbugs(){
        return bugs;
    }
    public int getants(){
        return ants;
    }
    //To initialize ants and bugs into character
    public char[][] getCGrid(){
        char[][] grid = new char[SIZE][SIZE];//0 to 19
        for(int i = 0; i < SIZE; i++){
            for(int j = 0;j < SIZE; j++){
                if(oGrid[j][i]!=null)
                    if(oGrid[j][i].getClass().getName().equals("Ant"))
                        grid[j][i] = 'A';
                    else if(oGrid[j][i].getClass().getName().equals("Bug"))
                        grid[j][i] = 'B';
                    else
                        grid[j][i] = ' ';

            }
        }
        return grid;
    }

    //mutators\\
    public void increasedoodlebugs(){
        bugs++;
    }
    public void decreasedoodlebugs(){
        bugs--;
    }
    public void increaseants(){
        ants++;
    }
    public void decreaseants(){
        ants--;
    }
    //methods\\
    //To move all organisms for each timesteps
    public void moveAll(){
        for(int i = 0; i < SIZE; i++){
            for(int j = 0;j < SIZE; j++){
                if(oGrid[j][i] !=null)
                    oGrid[j][i].move();

            }
        }
        for(int i = 0; i < SIZE; i++){
            for(int j = 0;j < SIZE; j++){
                if(oGrid[j][i] !=null)
                    oGrid[j][i].moved=false;

            }
        }
    }
    //To breed the organisms for each timesteps
    public void breedAll(){
        for(int i = 0; i < SIZE; i++){
            for(int j = 0;j < SIZE; j++){
                if(oGrid[j][i]!=null)
                    oGrid[j][i].breed();

            }
        }
    }
    //To initialize any starve organisms / bugs
    public void starveAll(){
        for(int i = 0; i < SIZE; i++){
            for(int j = 0;j < SIZE; j++){
                if(oGrid[j][i]!=null)
                    oGrid[j][i].starve();

            }
        }
    }
    //To check if the grid box is empty
    public boolean isEmpty(int x,int y){
        boolean box = false;
        if(oGrid[x][y]==null)
            box = true;
        return box;
    }
    //To check if the grid box is occupied with ants
    public boolean isAnt(int x,int y){
        boolean box = false;
        if(oGrid[x][y] instanceof Ant)
            box = true;
        return box;
    }
    //To set the organisms into the grid
    public void setCell(int x, int y, Organism O){
        oGrid[x][y] = O;
    }
    
    public boolean inBoundaries(int x, int y) {
        return (x >= 0 && x < SIZE) && (y >= 0 && y < SIZE);
    }
}


