
/**
 *
 * @author safwa
 */

/*
//Organism class
*/
public class Organism{
    protected boolean moved;
    protected int x;
    protected int y;
    protected World world;
    
    //Organism Constructor
    public Organism(World w,int _x, int _y){
        world = w;
        x = _x;
        y = _y;
    }
    //Method\\
    public void move(){
    }
    public void breed(){
    }
    public void starve(){
    }
}
